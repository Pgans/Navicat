SELECT c.VISIT_ID,c.reg_datetime, b.hn, a.fname, a.lname,e.unit_name
FROM population a, cid_hn b, opd_visits c, mobile_visits d, service_units e
WHERE 
c.reg_datetime BETWEEN '20160301' AND '20160315'
AND c.IS_CANCEL = 0
AND a.cid = b.cid
AND b.hn = c.hn
AND c.visit_id = d.visit_id
AND c.unit_id = e.unit_id
