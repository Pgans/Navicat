SELECT  DISTINCT '10953' AS HOSPCODE, cid_hn.HN AS PID, chronic_reg.REG_DATE AS DATE_DIAG,chronic_reg.ICD10 AS CHRONIC,
 '' AS HOSP_DX, chronic_reg.HOSP_ID AS HOSP_RX, DATE_FORMAT(chronic_reg.DSC_DATE,'%Y%m%d') AS DATE_DISCH,
 '' AS TYPEDISCH, DATE_FORMAT(NOW(),'%Y%m%d%H%i%s') AS D_UPDATE
FROM cid_hn,chronic_reg
WHERE chronic_reg.CID = cid_hn.CID AND chronic_reg.REG_DATE BETWEEN '2O14.01.01 00:00' AND '2014.02.01 23:59'