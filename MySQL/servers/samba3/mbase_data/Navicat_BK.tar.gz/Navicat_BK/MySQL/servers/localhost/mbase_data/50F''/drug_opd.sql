SELECT DISTINCT '10953' AS HOSPCODE, 
cid_hn.HN AS PID,  
opd_visits.VISIT_ID AS SEQ,  
DATE_FORMAT(opd_visits.REG_DATETIME,'%Y%m%d') AS DATE_SERV,
'' AS CLINIC,
'' AS DIDSTD, 
'' AS DNAME,
'' AS AMOUNT,
'' AS UNIT,
'' AS UNIT_PACKING,
'' AS DRUGPRICE,
'' AS DRUGCOST,
'' AS PROVIDER,
DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') AS D_UPDATE
FROM population,cid_hn
INNER JOIN opd_visits ON opd_visits.HN = cid_hn.HN 
INNER JOIN drugs ON 
WHERE opd_visits.REG_DATETIME BETWEEN '2014.01.01 00:00' AND '2014.01.03 23:59'
AND population.CID = cid_hn.CID
AND LEFT( population.cid, 5 ) > 00000 
AND opd_visits.IS_CANCEL = 0
AND opd_visits.visit_id NOT IN( SELECT visit_id FROM ipd_reg );