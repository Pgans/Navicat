SELECT DISTINCT
	'10953' AS HOSPCODE,
	cid_hn.HN AS PID,
	DATE_FORMAT(UPD_DT,'%Y%m%d') AS DATERECORD,
	b.DIDSTD AS DRUGALLERGY,
	b.DRUG_NAME AS DNAME,
	a.ADRTYPE AS TYPEDX,
	a. LEVEL AS ALEVEL,
	a.allergy_note AS SYMPTOM,
	'1' AS INFORMANT,
	'10953' AS INFORMHOSP,
	DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') AS D_UPDATE
FROM
	cid_hn,opd_visits,population
	INNER JOIN cid_drug_allergy a ON population.CID = a.CID
	INNER JOIN 	drugs b ON a.DRUG_ID = b.DRUG_ID
WHERE opd_visits.REG_DATETIME BETWEEN '2014.01.01 00:00' AND '2014.01.10 23:59'
AND cid_hn.CID = population.CID 
AND opd_visits.HN = cid_hn.HN
AND LEFT( population.cid, 5 ) > 00000 
AND opd_visits.IS_CANCEL = 0
AND opd_visits.visit_id NOT IN( SELECT visit_id FROM ipd_reg )
;